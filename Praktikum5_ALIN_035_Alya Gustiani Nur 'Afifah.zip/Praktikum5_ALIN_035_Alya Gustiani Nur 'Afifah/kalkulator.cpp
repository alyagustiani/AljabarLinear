#include <iostream>
#include <cstdio>
#include <cmath>

#define MAKS 10

using namespace std;

// Fungsi untuk mencari FPB (Faktor Persekutuan Terbesar)
int fpb(int a, int b) {
    if (b == 0) return a;
    return fpb(b, a % b);
}

// Fungsi untuk mengubah desimal menjadi pecahan
void desimalKePecahan(double desimal, int &pembilang, int &penyebut) {
    double presisi = 1e-6;  // Batas presisi untuk menghindari kesalahan pembulatan
    int penyebut_saat_ini = 1;

    // Mengubah desimal menjadi pecahan sederhana
    while (fabs(desimal - round(desimal)) > presisi) {
        desimal *= 10;
        penyebut_saat_ini *= 10;
    }

    pembilang = (int)round(desimal);
    penyebut = penyebut_saat_ini;

    // Mencari FPB agar pecahan dalam bentuk sederhana
    int fpb_pecahan = fpb(abs(pembilang), abs(penyebut));
    pembilang /= fpb_pecahan;
    penyebut /= fpb_pecahan;
}

// Fungsi untuk menampilkan pecahan
void cetakPecahan(double pembilang, double penyebut) {
    if (penyebut == 1) {
        printf("%.2f", pembilang);  // Menampilkan dalam format desimal
    } else {
        printf("%.2f/%.2f", pembilang, penyebut);
    }
}

void eliminasiGaussJordan(double matriks[MAKS][MAKS], int baris, int kolom) {
    int i, j, k;
    double rasio;

    printf("\n=========================================\n");
    printf("      METODE ELIMINASI GAUSS-JORDAN      \n");
    printf("=========================================\n");

    printf("\nMatriks awal:\n");
    for (i = 0; i < baris; i++) {
        for (j = 0; j < kolom; j++) {
            cetakPecahan(matriks[i][j], 1);  // Menampilkan elemen matriks awal
            printf("\t");
        }
        printf("\n");
    }

    for (i = 0; i < baris; i++) {
        // Membuat diagonal utama menjadi 1
        if (matriks[i][i] == 0) {
            printf("Proses Gauss-Jordan gagal, elemen diagonal tidak boleh 0.\n");
            return;
        }

        printf("\nOperasi: R%d / %.2f\n", i + 1, matriks[i][i]);
        double pembagi = matriks[i][i];
        for (j = 0; j < kolom; j++) {
            matriks[i][j] /= pembagi;  // Melakukan pembagian untuk membuat elemen diagonal 1
        }

        // Membuat elemen di atas dan di bawah diagonal menjadi 0
        for (j = 0; j < baris; j++) {
            if (i != j) {
                rasio = matriks[j][i];

                printf("Operasi: R%d - (", j + 1);
                cetakPecahan(rasio, 1);  // Menampilkan pecahan
                printf(") * R%d\n", i + 1);

                for (k = 0; k < kolom; k++) {
                    matriks[j][k] -= rasio * matriks[i][k];  // Operasi pengurangan
                }
            }
        }

        printf("\nMatriks setelah langkah %d:\n", i + 1);
        for (j = 0; j < baris; j++) {
            for (k = 0; k < kolom; k++) {
                cetakPecahan(matriks[j][k], 1);  // Menampilkan matriks setelah langkah
                printf("\t");
            }
            printf("\n");
        }
    }

    printf("\n=========================================\n");
    printf("                 SOLUSI                  \n");
    printf("=========================================\n");
    for (i = 0; i < baris; i++) {
        int pembilang, penyebut;
        printf("x[%d] = ", i + 1);
        printf("%.2f", matriks[i][kolom - 1]);  // Menampilkan solusi dalam bentuk desimal
        desimalKePecahan(matriks[i][kolom - 1], pembilang, penyebut);
        printf(" (%d/%d dalam pecahan)", pembilang, penyebut);  // Menampilkan solusi dalam bentuk pecahan
        printf("\n");
    }
}

int main() {
    int baris, kolom, i, j;
    double matriks[MAKS][MAKS];
    char ulang;

    do {
    	system("cls");
        printf("=========================================\n");
        printf("      KALKULATOR ELIMINASI GAUSS-JORDAN  \n");
        printf("=========================================\n\n");

        // Input ukuran matriks
        printf("Masukkan ukuran matriks:\n");
        printf("Jumlah baris: ");
        scanf("%d", &baris);
        printf("Jumlah kolom: ");
        scanf("%d", &kolom);
        printf("\nMatriks augmented memiliki ukuran %dx%d\n", baris, kolom);

        // Input elemen-elemen matriks augmented
        printf("\nMasukkan elemen augmented matriks:\n");
        for (i = 0; i < baris; i++) {
            for (j = 0; j < kolom; j++) {
                printf("Masukkan elemen matriks [%d][%d]: ", i + 1, j + 1);
                scanf("%lf", &matriks[i][j]);
            }
        }

        eliminasiGaussJordan(matriks, baris, kolom);

        // Menanyakan apakah ingin melakukan perhitungan lagi
        printf("\nApakah Anda ingin melakukan perhitungan lagi? (y/n): ");
        scanf(" %c", &ulang);  // Mengambil input untuk mengulang atau tidak
    } while (ulang == 'y' || ulang == 'Y');

    printf("Program selesai.\n");

    return 0;
}

